export type Difficulty = 'mudah' | 'sedang' | 'sulit';
export type GameMode = 'latihan' | 'ujian';
export type QuestionKind = 'mcq' | 'essay';

export type Question = {
  id: string;
  prompt: string;
  kind: QuestionKind;
  options?: string[];
  answer: string;
  explanation: string;
  topic: string;
};

const fmt = (value: number) => Number.isInteger(value) ? String(value) : String(Number(value.toFixed(2)));
const shuffled = <T,>(list: T[], seed: number) => list.map((item, index) => ({ item, key: Math.sin(seed * 17 + index * 91) })).sort((a, b) => a.key - b.key).map(({ item }) => item);
const distractors = (answer: number, seed: number) => shuffled([answer + 1, answer - 1, answer + 2, answer - 2, answer + 10, answer / 2].filter((n) => n !== answer && Number.isFinite(n)), seed).slice(0, 3).map(fmt);
const mcq = (id: string, prompt: string, answer: number, explanation: string, topic: string, seed: number): Question => {
  const correct = fmt(answer);
  return { id, prompt, kind: 'mcq', options: shuffled([correct, ...distractors(answer, seed)], seed + 2), answer: correct, explanation, topic };
};
const essay = (id: string, prompt: string, answer: number | string, explanation: string, topic: string): Question => ({ id, prompt, kind: 'essay', answer: String(answer), explanation, topic });

export function buildQuestionBank(level: number, difficulty: Difficulty): Question[] {
  const hard = difficulty === 'sulit';
  const medium = difficulty === 'sedang';
  const out: Question[] = [];
  const add = (q: Question) => out.push(q);
  const prefix = `k${level}-${difficulty}`;

  if (level <= 2) {
    for (let i = 0; i < 4; i++) {
      const a = level === 1 ? 4 + i * 3 : 12 + i * 4;
      const b = 2 + i;
      add(mcq(`${prefix}-a${i}`, `Berapakah ${a} + ${b}?`, a + b, `Tambahkan satuan: ${a} + ${b} = ${a + b}.`, 'Penjumlahan', i + level));
      add(mcq(`${prefix}-s${i}`, `Berapakah ${a + 8} − ${b}?`, a + 8 - b, `Kurangi ${b} dari ${a + 8}, hasilnya ${a + 8 - b}.`, 'Pengurangan', i + 9));
    }
    add(essay(`${prefix}-e1`, 'Tuliskan hasil dari 5 × 2.', 10, 'Perkalian 5 × 2 berarti menjumlahkan 5 sebanyak dua kali: 10.', 'Perkalian'));
    add(essay(`${prefix}-e2`, 'Ibu memiliki 15 permen dan membaginya kepada 3 anak sama rata. Berapa permen tiap anak?', 5, '15 dibagi 3 sama dengan 5.', 'Pembagian'));
    add(mcq(`${prefix}-g1`, 'Bentuk apakah yang memiliki 3 sisi?', 3, 'Segitiga memiliki tiga sisi.', 'Bangun datar', 33));
    add(mcq(`${prefix}-g2`, 'Jam menunjukkan pukul 07.00. Satu jam kemudian adalah pukul ...', 8, '07.00 ditambah satu jam menjadi 08.00.', 'Waktu', 34));
  } else if (level <= 5) {
    for (let i = 0; i < 4; i++) {
      const a = 24 + i * 7, b = 3 + i;
      add(mcq(`${prefix}-m${i}`, `Berapakah ${a} × ${b}?`, a * b, `${a} × ${b} = ${a * b}.`, 'Operasi bilangan', i + 22));
      add(mcq(`${prefix}-d${i}`, `Berapakah ${a * b} ÷ ${b}?`, a, `Karena ${a} × ${b} = ${a * b}, maka hasil pembagiannya adalah ${a}.`, 'Operasi bilangan', i + 42));
    }
    add(essay(`${prefix}-f1`, 'Sederhanakan pecahan 6/12. Tuliskan sebagai desimal atau pecahan.', 0.5, 'Bagi pembilang dan penyebut dengan 6: 6/12 = 1/2 = 0,5.', 'Pecahan'));
    add(essay(`${prefix}-f2`, 'Sebuah persegi panjang panjangnya 8 cm dan lebarnya 5 cm. Berapa luasnya?', 40, 'Luas = panjang × lebar = 8 × 5 = 40 cm².', 'Bangun datar'));
    add(mcq(`${prefix}-f3`, 'Berapakah bentuk persen dari pecahan 3/4?', 75, '3/4 sama dengan 75/100 atau 75%.', 'Pecahan', 71));
    add(mcq(`${prefix}-g3`, 'Keliling persegi dengan sisi 9 cm adalah ... cm', 36, 'Keliling persegi = 4 × sisi = 4 × 9 = 36 cm.', 'Bangun datar', 72));
  } else if (level <= 7) {
    for (let i = 0; i < 4; i++) {
      const a = 12 + i * 3, b = 4 + i;
      add(mcq(`${prefix}-r${i}`, `Nilai ${a} ÷ ${b} adalah ...`, a / b, `Bagi ${a} dengan ${b}, hasilnya ${a / b}.`, 'Rasio', i + 80));
      add(mcq(`${prefix}-z${i}`, `Berapakah ${a} − ${a + b}?`, -b, `Mengurangi bilangan yang lebih besar: ${a} − ${a + b} = ${-b}.`, 'Bilangan bulat', i + 90));
    }
    add(essay(`${prefix}-p1`, 'Hitung 25% dari 240.', 60, '25% = 1/4, jadi 240 ÷ 4 = 60.', 'Persentase'));
    add(essay(`${prefix}-p2`, 'Suhu −3°C naik 11°C. Berapa suhu sekarang?', 8, '−3 + 11 = 8°C.', 'Bilangan bulat'));
    add(mcq(`${prefix}-a1`, 'Jika x + 7 = 19, nilai x adalah ...', 12, 'Kurangi 7 dari kedua sisi: x = 19 − 7 = 12.', 'Aljabar', 101));
    add(mcq(`${prefix}-a2`, 'Luas segitiga dengan alas 10 cm dan tinggi 6 cm adalah ... cm²', 30, 'Luas = 1/2 × alas × tinggi = 1/2 × 10 × 6 = 30.', 'Bangun datar', 102));
  } else if (level === 8) {
    for (let i = 0; i < 4; i++) {
      const x = 3 + i, b = 5 + i;
      add(mcq(`${prefix}-l${i}`, `Jika 2x + ${b} = ${2 * x + b}, nilai x adalah ...`, x, `Kurangi ${b}, lalu bagi 2: x = ${x}.`, 'Persamaan linear', i + 110));
      add(mcq(`${prefix}-p${i}`, `Sebuah segitiga siku-siku memiliki sisi tegak ${x} dan alas ${x + 4}. Berapakah luasnya?`, (x * (x + 4)) / 2, 'Luas segitiga siku-siku = 1/2 × alas × tinggi.', 'Geometri', i + 120));
    }
    add(essay(`${prefix}-q1`, 'Sebuah dadu dilempar sekali. Berapa peluang muncul bilangan genap? Tuliskan desimalnya.', 0.5, 'Bilangan genap ada 3 dari 6 sisi, jadi peluangnya 3/6 = 0,5.', 'Peluang'));
    add(essay(`${prefix}-q2`, 'Hitung luas lingkaran berjari-jari 7 cm dengan π = 22/7.', 154, 'L = πr² = 22/7 × 7 × 7 = 154 cm².', 'Lingkaran'));
    add(mcq(`${prefix}-s1`, 'Gradien garis y = 3x − 2 adalah ...', 3, 'Pada y = mx + c, m adalah gradien. Jadi m = 3.', 'Fungsi linear', 132));
    add(mcq(`${prefix}-s2`, 'Suku ke-5 dari barisan 4, 7, 10, 13, ... adalah ...', 16, 'Barisan bertambah 3. Suku ke-5 = 13 + 3 = 16.', 'Barisan', 133));
  } else {
    for (let i = 0; i < 4; i++) {
      const x = 2 + i, b = 4 + i;
      add(mcq(`${prefix}-q${i}`, `Akar positif dari x² = ${(x * x)} adalah ...`, x, `Karena ${x}² = ${x * x}, akar positifnya adalah ${x}.`, 'Persamaan kuadrat', i + 140));
      add(mcq(`${prefix}-t${i}`, `Volume balok berukuran ${x} × ${b} × 5 cm adalah ... cm³`, x * b * 5, 'Volume balok = panjang × lebar × tinggi.', 'Bangun ruang', i + 150));
    }
    add(essay(`${prefix}-v1`, 'Jika f(x) = 2x + 3, berapakah f(7)?', 17, 'Substitusikan x = 7: f(7) = 2(7) + 3 = 17.', 'Fungsi'));
    add(essay(`${prefix}-v2`, 'Sebuah kerucut memiliki r = 3 cm, t = 4 cm, dan π = 3,14. Berapa volumenya?', 37.68, 'V = 1/3 × π × r² × t = 1/3 × 3,14 × 9 × 4 = 37,68 cm³.', 'Bangun ruang'));
    add(mcq(`${prefix}-w1`, 'Peluang mendapat angka lebih dari 4 saat melempar dadu adalah ...', 1 / 3, 'Hasil yang lebih dari 4 adalah 5 dan 6: 2/6 = 1/3.', 'Peluang', 162));
    add(mcq(`${prefix}-w2`, 'Sisi miring segitiga siku-siku dengan sisi 6 cm dan 8 cm adalah ... cm', 10, 'Teorema Pythagoras: √(6² + 8²) = √100 = 10.', 'Pythagoras', 163));
  }
  if (medium) out.push(mcq(`${prefix}-bonus1`, 'Berapakah hasil 12 + 8 × 2? Ingat urutan operasi.', 28, 'Perkalian dikerjakan lebih dahulu: 12 + (8 × 2) = 28.', 'Urutan operasi', 201));
  if (hard) out.push(essay(`${prefix}-bonus2`, 'Hitung 3/4 + 0,25. Tuliskan desimalnya.', 1, '3/4 = 0,75, lalu 0,75 + 0,25 = 1.', 'Pecahan'));
  return out;
}

export function isAnswerCorrect(input: string, answer: string): boolean {
  const normalize = (value: string) => value.toLowerCase().trim().replace(/,/g, '.').replace(/[a-z²³^%°]/g, '').replace(/\s+/g, '');
  const a = normalize(input);
  const b = normalize(answer);
  if (a === b) return true;
  const na = Number(a), nb = Number(b);
  return Number.isFinite(na) && Number.isFinite(nb) && Math.abs(na - nb) < 0.011;
}

export function shuffleQuestions(questions: Question[]): Question[] {
  return [...questions].sort(() => Math.random() - 0.5);
}